function main()

{

	model.sessionTicket = session.getTicket();

}

main();
