function main()

 
{

    var json = remote.call("/get-ticket");

 

    if (json.status == 200)

    {

        obj = eval('(' + json + ')');

        model.result = obj;

    }

 
	model.sessionTicket = sessionticket.getTicket();
}

main();
