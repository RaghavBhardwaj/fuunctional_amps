function main()

{

	model.sessionTicket = sessionticket.getTicket();
}

main();
